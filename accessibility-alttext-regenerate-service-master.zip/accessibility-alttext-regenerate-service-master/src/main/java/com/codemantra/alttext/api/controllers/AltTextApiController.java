package com.codemantra.alttext.api.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author codemantra
 */
// @CrossOrigin
@RequestMapping("/altTextGeneration")
@RestController
public class AltTextApiController {

}
