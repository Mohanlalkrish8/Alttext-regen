package com.codemantra.alttext.service;

import com.codemantra.alttext.api.model.AltText;

public interface AltTextService {

	public void processAltTextRegenerate(AltText altTextItem);

}
